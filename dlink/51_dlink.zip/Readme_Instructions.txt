D-Link xStack (DGS-3324SR, DGS-3324SRi, DXS-3326GSR, DXS-3350SR)

Caution: Improper upgrading of PROM may damage the device. Please read the included upgrade procedure        carefully.

xStack switches with different PROM versions (1.x or 2.x) cannot stack together.  In order for the switches to stack properly, all units must have either 1.x or 2.x PROM versions.  If switches have different PROM versions, all 1.x units should be upgraded to PROM 2.x.

Note: Please upgrade the PROM code before upgrading the Firmware Image.


PROM 2.01B01 Enhancements:
	1. Support "dual image Feature  
	2. Improve bootup time

